﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flappy_Bird_Windows_Form
{
    public partial class Form1 : Form
    {

        // coded game Flappy Bird 

        // 

        int pipeSpeed = 8; // tốc độ đường ống mặc định được xác định bằng một số nguyên
        int gravity = 15; // tốc độ trọng lực mặc định được xác định bằng một số nguyên
        int score = 0; // số nguyên điểm mặc định được đặt thành 0
        // kết thúc biến 

        public Form1()
        {
            InitializeComponent();
        }

        private void gamekeyisdown(object sender, KeyEventArgs e)
        {
            // đây là sự kiện chìa khóa trò chơi không hoạt động được liên kết với fprm  chính
            if (e.KeyCode == Keys.Space)
            {
                // nếu nhấn phím cách thì trọng lực sẽ được đặt thành -15
                gravity = -15;
            }


        }

        private void gamekeyisup(object sender, KeyEventArgs e)
        {
            // đây là sự kiện key is up của trò chơi được liên kết với biểu mẫu chính

            if (e.KeyCode == Keys.Space)
            {
                // nếu phím cách được nhả ra thì trọng lực được đặt trở lại 15
                gravity = 15;
            }

        }

        private void endGame()
        {
            // đây là chức năng kết thúc trò chơi, chức năng này sẽ hoạt động khi chú chim chạm đất hoặc đường ống
            gameTimer.Stop(); // dừng bộ đếm thời gian chính
            scoreText.Text += " Nước mắt tuôn rơi trò chơi có phí!!!"; // hiển thị trò chơi trên văn bản trên văn bản tỷ số, += được sử dụng để thêm chuỗi văn bản mới bên cạnh tỷ số thay vì ghi đè lên nó
        }

        private void gameTimerEvent(object sender, EventArgs e)
        {
            flappyBird.Top += gravity; // liên kết hộp hình chú chim flappy với trọng lực, += có nghĩa là nó sẽ thêm tốc độ của trọng lực vào vị trí trên cùng của hộp hình để nó di chuyển xuống dưới
            pipeBottom.Left -= pipeSpeed; // liên kết vị trí bên trái của đường ống dưới cùng với số nguyên tốc độ đường ống, nó sẽ giảm giá trị tốc độ đường ống từ vị trí bên trái của hộp hình đường ống để nó sẽ di chuyển sang trái với mỗi tích tắc
            pipeTop.Left -= pipeSpeed; // điều tương tự cũng xảy ra với đường ống trên cùng, hãy giảm giá trị của số nguyên tốc độ đường ống từ vị trí bên trái của đường ống bằng cách sử dụng dấu -=
            scoreText.Text = "Điểm: " + score; // hiển thị điểm hiện tại trên nhãn văn bản điểm

            // bên dưới đang kiểm tra xem có đường ống nào rời khỏi màn hình không

            if (pipeBottom.Left < -150)
            {
                //nếu vị trí ống dưới cùng là -150 thì  sẽ đặt lại thành 800 và thêm 1 vào điểm số
                pipeBottom.Left = 800;
                score++;
            }
            if(pipeTop.Left < -180)
            {
                // nếu vị trí đường ống trên cùng là -180 thì  sẽ đặt lại đường ống về 950 và thêm 1 vào điểm số
                pipeTop.Left = 950;
                score++;
            }

            // câu lệnh if bên dưới đang kiểm tra xem đường ống có chạm đất, đường ống hay người chơi đã rời khỏi màn hình từ trên xuống
            //  biểu tượng || là viết tắt của OR bên trong câu lệnh if để chúng ta có thể có nhiều điều kiện bên trong câu lệnh if này vì tất cả sẽ thực hiện cùng một việc

            if (flappyBird.Bounds.IntersectsWith(pipeBottom.Bounds) ||
                flappyBird.Bounds.IntersectsWith(pipeTop.Bounds) ||
                flappyBird.Bounds.IntersectsWith(ground.Bounds) || flappyBird.Top < -25
                )
            {
                // nếu bất kỳ điều kiện nào được đáp ứng ở trên thì  sẽ chạy chức năng kết thúc trò chơi
                endGame();
            }


            // nếu điểm lớn hơn 5 thì chúng ta sẽ tăng tốc độ đường ống lên 15
            if (score > 5)
            {
                pipeSpeed = 15;
            }

        }

 
    }
}
